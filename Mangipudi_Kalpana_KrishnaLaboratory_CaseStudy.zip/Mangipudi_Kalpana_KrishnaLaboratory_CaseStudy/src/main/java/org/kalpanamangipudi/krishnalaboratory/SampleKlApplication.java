package org.kalpanamangipudi.krishnalaboratory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan(basePackages ="org.kalpanamangipudi.krishnalaboratory")
@EnableJpaRepositories(basePackages ="org.kalpanamangipudi.krishnalaboratory.repository")
@EntityScan(basePackages = "org.kalpanamangipudi.krishnalaboratory.entity")
public class SampleKlApplication {

	public static void main(String[] args) {
		System.out.println("Application is starting...");
		try {
			SpringApplication.run(SampleKlApplication.class, args);
		} catch (Exception e) {
			System.err.println("Application failed to start:");
			e.printStackTrace();
		}
	}

}
