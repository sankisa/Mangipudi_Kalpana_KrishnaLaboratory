package org.kalpanamangipudi.krishnalaboratory.controllers;

import org.kalpanamangipudi.krishnalaboratory.entity.DoctorAppointments;
import org.kalpanamangipudi.krishnalaboratory.service.DoctorAppointmentsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AppointmentController {
    private DoctorAppointmentsService doctorAppointmentsService;
    @Autowired
    public AppointmentController(DoctorAppointmentsService doctorAppointmentsService) {
        this.doctorAppointmentsService = doctorAppointmentsService;
    }
    @GetMapping("/book-appointment")
    public String showAppointmentForm(Model model) {
        model.addAttribute("appointmentForm", new DoctorAppointments());
        return "book-appointment";
    }

    @PostMapping("/book-appointment")
    public String submitAppointmentForm(@ModelAttribute("appointment-Form") DoctorAppointments doctorAppointments) {

        doctorAppointmentsService.createDoctorAppointments(doctorAppointments);
        return "confirm-appointment.html";



    }
}
