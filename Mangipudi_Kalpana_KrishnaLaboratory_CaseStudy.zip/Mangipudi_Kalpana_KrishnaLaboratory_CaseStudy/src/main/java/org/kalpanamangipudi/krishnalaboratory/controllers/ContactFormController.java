package org.kalpanamangipudi.krishnalaboratory.controllers;

import org.kalpanamangipudi.krishnalaboratory.entity.ContactForm;
import org.kalpanamangipudi.krishnalaboratory.service.ContactFormService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ContactFormController {

    private ContactFormService contactFormService;

    @Autowired
    public ContactFormController(ContactFormService contactFormService) {
        this.contactFormService = contactFormService;
    }
    @GetMapping("/contact-us")
    public String showSignupForm(Model model) {
        model.addAttribute("contactForm", new ContactForm());
        return "contact-us";
   }
    @PostMapping("/submit-contact-form")
        public String submitContactForm(@ModelAttribute("contactForm") ContactForm contactForm) {
       contactFormService.saveContactForm(contactForm);
        return "contact-success";

}
}
