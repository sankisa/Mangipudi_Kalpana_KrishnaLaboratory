package org.kalpanamangipudi.krishnalaboratory.controllers;

import org.kalpanamangipudi.krishnalaboratory.entity.User;
import org.kalpanamangipudi.krishnalaboratory.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LoginController {
    private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

    private UserRepository userRepository;
    @Autowired
    public LoginController(UserRepository userRepository) {
        this.userRepository = userRepository;

    }
    @GetMapping("/login")
    public String login(Model model) {
        model.addAttribute("user", new User());
        return "login";
    }

    @PostMapping("/submit-login")
    public String loginSubmit(@ModelAttribute @Validated User user, BindingResult bindingResult, Model model) {

        if (bindingResult.hasErrors()) {
            logger.debug("Validation errors: {}", bindingResult.getAllErrors());
            return "login";
        }
        User storedUser = userRepository.findUserByUsername(user.getUsername());
        if (storedUser == null || !storedUser.getPassword().equals(user.getPassword())){
            model.addAttribute("error", "Invalid username or password");
            logger.debug("Invalid username or password for user: {}", user.getUsername());
            return "login";
        }
        logger.debug("Successful login for user: {}", user.getUsername());
        return "/login-success";
            }

        }










