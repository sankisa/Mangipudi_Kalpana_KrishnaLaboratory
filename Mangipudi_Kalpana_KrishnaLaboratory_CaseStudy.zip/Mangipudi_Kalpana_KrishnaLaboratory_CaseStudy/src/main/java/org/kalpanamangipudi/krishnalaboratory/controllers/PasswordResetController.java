package org.kalpanamangipudi.krishnalaboratory.controllers;

import org.kalpanamangipudi.krishnalaboratory.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
@Controller
public class PasswordResetController {
    @Autowired
    private UserServiceImpl userServiceImpl;

    @GetMapping("/forgot-password")
    public String showForgotPasswordForm() {
        return "forgot-password";
    }

    @PostMapping("/forgot-password")
    public String processForgotPassword(@RequestParam("email") String email, Model model) {

        userServiceImpl.processForgotPassword(email);
        model.addAttribute("message", "Password reset instructions sent to your email.");
        return "forgot-password";
    }

    @GetMapping("/reset-password")
    public String showResetPasswordForm(@RequestParam("token") String token, Model model) {
        // Verify the token and show the reset password form
        boolean isValidToken = userServiceImpl.verifyPasswordResetToken(token);
        if (isValidToken) {
            model.addAttribute("token", token);
            return "reset-password-form";
        } else {

            model.addAttribute("message", "Invalid or expired token.");
            return "error";
        }
    }

    @PostMapping("/reset-password-form")
    public String processResetPassword(@RequestParam("token") String token,
                                       @RequestParam("password") String newPassword,
                                       Model model) {

        boolean passwordUpdated = userServiceImpl.resetPassword(token, newPassword);
        if (passwordUpdated) {
            model.addAttribute("message", "Password successfully reset.");
            return "login";
        } else {

            model.addAttribute("message", "Password reset failed.");
            return "reset-password";
        }
    }
}

