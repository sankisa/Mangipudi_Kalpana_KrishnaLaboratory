package org.kalpanamangipudi.krishnalaboratory.controllers;

import org.kalpanamangipudi.krishnalaboratory.entity.Products;
import org.kalpanamangipudi.krishnalaboratory.service.ProductsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;


@Controller
public class ProductController {

    @Autowired
    private ProductsService productsService;

    @GetMapping("/products")
    public String showProductsPage(Model model) {
        return "products";

    }


    @GetMapping("/userProducts")
    public String userProducts(Model model) {
        return "userProducts";
    }



}
