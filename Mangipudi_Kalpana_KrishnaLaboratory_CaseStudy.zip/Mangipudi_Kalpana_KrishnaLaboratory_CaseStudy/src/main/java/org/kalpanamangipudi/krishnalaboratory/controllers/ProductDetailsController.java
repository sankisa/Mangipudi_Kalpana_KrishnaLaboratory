package org.kalpanamangipudi.krishnalaboratory.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class ProductDetailsController {
    @GetMapping("/product-details")
    public String showProductsPage(Model model) {
        return "product-details";

    }
}
