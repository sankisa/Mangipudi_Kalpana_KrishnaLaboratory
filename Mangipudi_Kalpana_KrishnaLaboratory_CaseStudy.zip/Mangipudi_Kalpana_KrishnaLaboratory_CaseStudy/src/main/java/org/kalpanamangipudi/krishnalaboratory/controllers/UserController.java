package org.kalpanamangipudi.krishnalaboratory.controllers;



import org.kalpanamangipudi.krishnalaboratory.dto.UserDTO;
import org.kalpanamangipudi.krishnalaboratory.entity.User;
import org.kalpanamangipudi.krishnalaboratory.service.UserService;
import org.kalpanamangipudi.krishnalaboratory.service.UserServiceImpl;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@Slf4j

    public class UserController {
    @InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        StringTrimmerEditor stringTrimmerEditor = new StringTrimmerEditor(true);
        dataBinder.registerCustomEditor(String.class, stringTrimmerEditor);
    }


    private UserServiceImpl userDetailsService;



    @Autowired
    public UserController(UserServiceImpl userDetailsService, UserService userService) {
        this.userDetailsService = userDetailsService;

    }

    @GetMapping("/signup")
    public String showSignupForm(Model model) {
        model.addAttribute("userDto", new UserDTO());
        return "signup";
    }

    @PostMapping("/submit-form")
    public String processSignupForm(@Valid @ModelAttribute("userDto") UserDTO userDTO, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            log.warn("Wrong Input");
            return "signup";
        }
        userDetailsService.saveUser(userDTO);
        return "confirmation-signup";
    }
    @RequestMapping("/index")
    public String getHome() {
        log.info("home page displayed");
        return "index";
    }



}



