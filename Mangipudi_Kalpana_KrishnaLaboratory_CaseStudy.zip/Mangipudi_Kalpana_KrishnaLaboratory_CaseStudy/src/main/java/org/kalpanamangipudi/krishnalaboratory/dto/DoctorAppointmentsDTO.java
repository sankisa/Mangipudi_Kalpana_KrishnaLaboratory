package org.kalpanamangipudi.krishnalaboratory.dto;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Table(name="Doctor_Appointments")
@Entity

public class DoctorAppointmentsDTO{


       @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        @NotEmpty(message = "Patient name is required")

        private String patientName;
        @NotEmpty(message = "Doctor name is required")
        private String doctorName;

        @Temporal(TemporalType.DATE)
        @DateTimeFormat(pattern = "yyyy-MM-dd")
        private Date date;

        @NotEmpty(message = "Appointment Time is required")
        private String appointmentTime;

        @NotEmpty(message = "Contact number is required")
        private String contactNumber;

        @NotEmpty(message = "Reason for visit is required")
        private String reason;
    }

