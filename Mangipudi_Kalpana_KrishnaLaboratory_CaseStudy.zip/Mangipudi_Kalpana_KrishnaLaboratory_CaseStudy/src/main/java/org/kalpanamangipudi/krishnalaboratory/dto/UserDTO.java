package org.kalpanamangipudi.krishnalaboratory.dto;

import org.kalpanamangipudi.krishnalaboratory.entity.Role;
import org.kalpanamangipudi.krishnalaboratory.security.FieldMatch;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@NoArgsConstructor
    @Getter
    @Setter
    @FieldMatch.List( { @FieldMatch(firstPwd = "password", secondPwd = "confirmPassword", message = "The password fields must match")})
    public class UserDTO {
        @Pattern(regexp = "[A-Za-z]+$", message = "Only alphabetic allowed")
        private String firstName;

        @Pattern(regexp = "[A-Za-z]+$", message = "Only alphabetic allowed")
        private String lastName;

        @Min(value = 18, message = "Age must be at least 18")
        @Max(value = 80, message = "Age must be at most 80")
        private int age;

        private String address;
        private String city;
        private String state;
        @Pattern(regexp = "[0-9]{5}$", message = "Zip code wrong format")
        private String zip;

        @NotEmpty(message = "Country is required")
        private String country;

        @Email(message = "Invalid email address")
        @Column(unique=true)
        private String email;

        @NotEmpty()
        private String username;

        @NotEmpty(message = "Password is required")
        private String password;

        @NotEmpty(message = "Confirm password is required")
        private String confirmPassword;

        public UserDTO(String firstName, String lastName, int age, String address, String city, String state, String zip, String country, String email, String username, String password, String confirmPassword) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.age = age;
            this.address = address;
            this.city = city;
            this.state = state;
            this.zip = zip;
            this.country = country;
            this.email = email;
            this.username = username;
            this.password = password;
            this.confirmPassword = confirmPassword;
        }
    private List<Role> role;

    public List<Role> getRole() {
        return role;
    }

    public void setRole(List<Role> role) {
        this.role = role;
    }
}

