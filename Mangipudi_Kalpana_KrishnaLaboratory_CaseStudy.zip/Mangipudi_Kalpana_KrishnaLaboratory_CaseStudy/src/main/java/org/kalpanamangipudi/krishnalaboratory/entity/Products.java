package org.kalpanamangipudi.krishnalaboratory.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Entity
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Table(name="Products")
public class Products {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String description;
    private double price;
    private String imageUrl;
    private int quantity;

    @OneToOne(mappedBy = "product")
    private Inventory inventory;
}
