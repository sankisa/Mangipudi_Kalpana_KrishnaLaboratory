package org.kalpanamangipudi.krishnalaboratory.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


@NoArgsConstructor
    @Getter
    @Setter
    @AllArgsConstructor
    @Table(name="User")
    @Entity
    @ToString
    public class User {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "user_id")
        private Long userId;
        @OneToMany(mappedBy = "user",cascade = CascadeType.ALL)
        private List<Cart> cartItems;

        @NotEmpty(message = "First name is required")
        private String firstName;

        @NotEmpty(message = "Last name is required")
        private String lastName;

        @Min(value = 18, message = "Age must be at least 18")
        @Max(value = 80, message = "Age must be at most 80")
        private int age;

        private String address;
        private String city;
        private String state;
        private String zip;

        @NotEmpty(message = "Country is required")
        private String country;
@Column(name="email")
        @Email(message = "Invalid email address")
        @NotEmpty(message = "Email is required")
        private String email;

        @NotEmpty(message = "Username is required")
        private String username;

        @NotEmpty(message = "Password is required")
        @Size(min = 6, message = "Password must be at least 6 characters")
        private String password;

        @NotEmpty(message = "Confirm password is required")
        @Transient
        private String confirmPassword;

        @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
        @JoinTable(name = "user_roles", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "role_id"))
        private Collection<Role> roles;


        }



