package org.kalpanamangipudi.krishnalaboratory.repository;

import org.kalpanamangipudi.krishnalaboratory.entity.ContactForm;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface ContactFormRepository extends CrudRepository<ContactForm, Long>
{
        List<ContactForm> findByEmail(String email);
        List<ContactForm> findByNameAndEmail(String name, String email);

}

