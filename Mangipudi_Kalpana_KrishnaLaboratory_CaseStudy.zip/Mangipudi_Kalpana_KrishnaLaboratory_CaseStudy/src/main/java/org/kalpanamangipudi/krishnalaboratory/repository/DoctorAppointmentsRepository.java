package org.kalpanamangipudi.krishnalaboratory.repository;

import org.kalpanamangipudi.krishnalaboratory.entity.DoctorAppointments;
import org.springframework.data.repository.CrudRepository;

import java.util.Date;


public interface DoctorAppointmentsRepository extends CrudRepository<DoctorAppointments, Long> {
    DoctorAppointments findByDoctorName(String doctorName);
    DoctorAppointments findByDate(Date date);
    DoctorAppointments findDoctorByPatientName(String patientName);
}
