package org.kalpanamangipudi.krishnalaboratory.security;

import java.lang.annotation.*;

public @interface FieldMatch {
    String message() default "Fields do not match";
    Class<?>[] groups() default {};
    Class<?>[] payload() default {};

    String firstPwd();
    String secondPwd();
    @Target({ ElementType.TYPE, ElementType.ANNOTATION_TYPE })
    @Retention(RetentionPolicy.RUNTIME)
    @Documented
    @interface List
    {
        FieldMatch[] value();
    }
}


