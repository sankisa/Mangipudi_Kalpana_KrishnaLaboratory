package org.kalpanamangipudi.krishnalaboratory.security;

import org.kalpanamangipudi.krishnalaboratory.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;


import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.servlet.util.matcher.MvcRequestMatcher;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.servlet.handler.HandlerMappingIntrospector;


@Configuration
@EnableWebSecurity
public class SecurityConfig {
    @Autowired
    private UserServiceImpl userDetailsService;

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider auth = new DaoAuthenticationProvider();
        auth.setUserDetailsService((UserDetailsService) userDetailsService);
        auth.setPasswordEncoder(passwordEncoder()); //set the password encoder - bcrypt
        return auth;
    }

    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(11);
    }

    @Bean
    protected SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        MvcRequestMatcher matcher0=new MvcRequestMatcher(new HandlerMappingIntrospector(),"/");
        MvcRequestMatcher matcher01=new MvcRequestMatcher(new HandlerMappingIntrospector(),"/index");
        MvcRequestMatcher matcher1 = new MvcRequestMatcher(new HandlerMappingIntrospector(), "/about");
        MvcRequestMatcher matcher2 = new MvcRequestMatcher(new HandlerMappingIntrospector(), "/static/photos/*");
        MvcRequestMatcher matcher3 = new MvcRequestMatcher(new HandlerMappingIntrospector(), "/static/css/*");
        MvcRequestMatcher matcher4 = new MvcRequestMatcher(new HandlerMappingIntrospector(), "/static/javascript/*");
        MvcRequestMatcher matcher5 = new MvcRequestMatcher(new HandlerMappingIntrospector(), "/login");
        MvcRequestMatcher matcher6 = new MvcRequestMatcher(new HandlerMappingIntrospector(), "/product-details");
        MvcRequestMatcher matcher7 = new MvcRequestMatcher(new HandlerMappingIntrospector(), "/signup");
        MvcRequestMatcher matcher8 = new MvcRequestMatcher(new HandlerMappingIntrospector(), "/submit-form");
        MvcRequestMatcher matcher9 = new MvcRequestMatcher(new HandlerMappingIntrospector(), "/contact-us");
        MvcRequestMatcher matcher10 = new MvcRequestMatcher(new HandlerMappingIntrospector(), "/book-appointment");
        MvcRequestMatcher matcher11 = new MvcRequestMatcher(new HandlerMappingIntrospector(), "/confirmation-signup");
        MvcRequestMatcher matcher12 = new MvcRequestMatcher(new HandlerMappingIntrospector(), "/confirm-appointment");
        MvcRequestMatcher matcher13 = new MvcRequestMatcher(new HandlerMappingIntrospector(), "/submit-contact-form");
        MvcRequestMatcher matcher15 = new MvcRequestMatcher(new HandlerMappingIntrospector(), "/userProducts");
        MvcRequestMatcher matcher16 = new MvcRequestMatcher(new HandlerMappingIntrospector(), "/shop");
        MvcRequestMatcher matcher17 = new MvcRequestMatcher(new HandlerMappingIntrospector(), "/forgot-password");

        http

                .authorizeRequests()
                        .requestMatchers(matcher0,matcher01,matcher1,matcher2,matcher3,matcher4,matcher6,
                                matcher7,matcher8,matcher9,matcher10,matcher11,matcher12,matcher13,matcher15,matcher16,matcher17)
                .permitAll()

                .anyRequest().authenticated()
                .and()
                .formLogin(form->form
                        .loginPage("/login")
                        .loginProcessingUrl("/submit-login")
                        .defaultSuccessUrl("/login-success",true)
                .permitAll())


                .logout(logout -> logout
                                        .invalidateHttpSession(true)
                                        .clearAuthentication(true)
                                        .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                        .deleteCookies("JSESSIONID")
                                        .permitAll());



                        return http.build();
    }

    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
    }


}









