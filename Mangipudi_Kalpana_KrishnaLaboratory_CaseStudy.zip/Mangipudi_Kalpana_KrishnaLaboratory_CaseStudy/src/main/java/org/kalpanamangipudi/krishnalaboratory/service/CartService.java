package org.kalpanamangipudi.krishnalaboratory.service;

import org.kalpanamangipudi.krishnalaboratory.entity.Cart;
import org.kalpanamangipudi.krishnalaboratory.entity.Products;
import org.kalpanamangipudi.krishnalaboratory.entity.User;

import java.util.List;

public interface CartService {
    public Cart createCart(User user);

    public Cart addToCart(Cart cart, Products product, int quantity);

    public Cart updateCart(Cart cart);

    public Cart getCartById(Long cartId);

    public List<Cart> getUserCarts(User user);
    public Cart removeFromCart(Cart cart, Products product,int quantity);

}