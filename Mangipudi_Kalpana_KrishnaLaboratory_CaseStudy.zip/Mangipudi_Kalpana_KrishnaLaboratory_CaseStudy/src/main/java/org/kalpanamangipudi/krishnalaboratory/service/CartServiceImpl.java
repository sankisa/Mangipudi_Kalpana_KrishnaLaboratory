package org.kalpanamangipudi.krishnalaboratory.service;

import org.kalpanamangipudi.krishnalaboratory.entity.Cart;
import org.kalpanamangipudi.krishnalaboratory.entity.Products;
import org.kalpanamangipudi.krishnalaboratory.entity.User;
import org.kalpanamangipudi.krishnalaboratory.repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CartServiceImpl implements CartService {
    @Autowired
    private final CartRepository cartRepository;

    @Autowired
    public CartServiceImpl(CartRepository cartRepository) {
        this.cartRepository = cartRepository;
    }

    @Override
    @Transactional
    public Cart createCart(User user) {
        Cart cart = new Cart();
        cart.setUser(user);
        return cartRepository.save(cart);
    }


    @Override
    @Transactional
    public Cart addToCart(Cart cart, Products product, int quantity) {
        if (cart == null || product == null) {
            throw new IllegalArgumentException("Invalid cart or product");
        }
        List<Products> productsInCart = cart.getProducts();
        if (productsInCart.contains(product)) {
            int index = productsInCart.indexOf(product);
            Products productInCart = productsInCart.get(index);
            productInCart.setQuantity(productInCart.getQuantity() + quantity);
        } else {
            product.setQuantity(quantity);
            productsInCart.add(product);
        }
        updateCartTotal(cart);

        return cartRepository.save(cart);
    }

    @Override
    @Transactional
    public Cart updateCart(Cart cart) {
        return cartRepository.save(cart);
    }

    @Override
    @Transactional
    public Cart getCartById(Long cartId) {
        return cartRepository.findById(cartId).orElse(null);
    }

    @Override
    @Transactional
    public List<Cart> getUserCarts(User user) {
        List<Cart> carts = cartRepository.findByUser(user);
        if (carts.isEmpty()) {
            Cart newCart = createCart(user);
            carts.add(newCart);
        }
        return carts;
    }
    public Cart removeFromCart(Cart cart, Products product, int quantity) {
        List<Products> productsInCart = cart.getProducts();

        if (productsInCart.contains(product)) {
            int index = productsInCart.indexOf(product);
            Products productInCart = productsInCart.get(index);

            int currentQuantity = productInCart.getQuantity();

            if (currentQuantity <= quantity) {
                productsInCart.remove(index);
            } else {

                productInCart.setQuantity(currentQuantity - quantity);
            }
            updateCartTotal(cart);
            return cartRepository.save(cart);
        }

        return cart;
    }









    private void updateCartTotal(Cart cart) {
        List<Products> productsInCart = cart.getProducts();
        int totalQuantity = 0;
        double totalPrice = 0.0;

        for (Products product : productsInCart) {
            totalQuantity += product.getQuantity();
            totalPrice += product.getPrice() * product.getQuantity();
        }

        cart.setTotalQuantity(totalQuantity);
        cart.setTotalPrice(totalPrice);
    }
}
