package org.kalpanamangipudi.krishnalaboratory.service;

import org.kalpanamangipudi.krishnalaboratory.entity.ContactForm;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface ContactFormService {
    ContactForm saveContactForm(ContactForm contactForm);


    List<ContactForm> getContactsByEmail(String email);
    List<ContactForm> getContactsByNameAndEmail(String name, String email);

}
