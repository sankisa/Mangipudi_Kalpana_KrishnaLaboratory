package org.kalpanamangipudi.krishnalaboratory.service;

import org.kalpanamangipudi.krishnalaboratory.entity.ContactForm;
import org.kalpanamangipudi.krishnalaboratory.repository.ContactFormRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ContactFormServiceImpl implements ContactFormService {

    @Autowired
    private ContactFormRepository contactFormRepository;

    @Override
    public ContactForm saveContactForm(ContactForm contactForm) {
        return contactFormRepository.save(contactForm);
    }



    @Override
    public List <ContactForm> getContactsByEmail(String email) {
        return contactFormRepository.findByEmail(email);
    }

    @Override
    public List<ContactForm> getContactsByNameAndEmail(String name, String email) {
        return contactFormRepository.findByNameAndEmail(name, email);
    }
}