package org.kalpanamangipudi.krishnalaboratory.service;

import org.kalpanamangipudi.krishnalaboratory.entity.DoctorAppointments;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
@Service
public interface DoctorAppointmentsService {

        DoctorAppointments createDoctorAppointments(DoctorAppointments doctorAppointments);
        List<DoctorAppointments> getAllAppointments();
        DoctorAppointments getDoctorAppointmentsById(Long id);
        List<DoctorAppointments> getAllAppointmentsByDoctorName(String doctorName);

        List<DoctorAppointments> getAllAppointmentsByDate(Date date);
    }


