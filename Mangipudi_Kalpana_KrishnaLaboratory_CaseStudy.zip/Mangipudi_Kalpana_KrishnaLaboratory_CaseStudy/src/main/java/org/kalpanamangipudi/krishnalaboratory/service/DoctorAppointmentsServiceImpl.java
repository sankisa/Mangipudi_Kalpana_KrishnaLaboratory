package org.kalpanamangipudi.krishnalaboratory.service;

import org.kalpanamangipudi.krishnalaboratory.entity.DoctorAppointments;
import org.kalpanamangipudi.krishnalaboratory.repository.DoctorAppointmentsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
@Service
public class DoctorAppointmentsServiceImpl implements DoctorAppointmentsService {
    @Autowired
    private DoctorAppointmentsRepository doctorAppointmentsRepository;

    @Override
    public DoctorAppointments createDoctorAppointments(DoctorAppointments doctorAppointments) {

        return doctorAppointmentsRepository.save(doctorAppointments);
    }

    @Override
    public List<DoctorAppointments> getAllAppointments() {
        return (List<DoctorAppointments>) doctorAppointmentsRepository.findAll();
    }

    @Override
    public DoctorAppointments getDoctorAppointmentsById(Long id) {
        return doctorAppointmentsRepository.findById(id).orElse(null);
    }

    @Override
    public List<DoctorAppointments> getAllAppointmentsByDoctorName(String doctorName) {
        return (List<DoctorAppointments>) doctorAppointmentsRepository.findByDoctorName(doctorName);
    }



    @Override
    public List<DoctorAppointments> getAllAppointmentsByDate(Date date) {
        return (List<DoctorAppointments>) doctorAppointmentsRepository.findByDate(date);
    }
}