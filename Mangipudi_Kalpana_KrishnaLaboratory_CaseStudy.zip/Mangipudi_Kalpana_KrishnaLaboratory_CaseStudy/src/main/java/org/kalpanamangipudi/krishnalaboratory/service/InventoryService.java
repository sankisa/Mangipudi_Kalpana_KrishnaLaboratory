package org.kalpanamangipudi.krishnalaboratory.service;

import org.kalpanamangipudi.krishnalaboratory.entity.Inventory;

import java.util.List;

public interface InventoryService {

    public Inventory saveOrUpdateInventory(Inventory inventory);
    public List<Inventory> getAllInventory();
    public Inventory getInventoryById(Long id);
    public void deleteInventoryById(Long id);
    public List<Inventory> getInventoryByProductName(String productName);
}
