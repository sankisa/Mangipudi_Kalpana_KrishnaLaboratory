package org.kalpanamangipudi.krishnalaboratory.service;

import org.kalpanamangipudi.krishnalaboratory.entity.Inventory;
import org.kalpanamangipudi.krishnalaboratory.repository.InventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class InventoryServiceImpl implements InventoryService{
    private InventoryRepository inventoryRepository;

    @Autowired
    public void InventoryService(InventoryRepository inventoryRepository) {
        this.inventoryRepository = inventoryRepository;
    }

    @Override
    public Inventory saveOrUpdateInventory(Inventory inventory) {
        return inventoryRepository.save(inventory);
    }

    @Override
    public List<Inventory> getAllInventory() {
        return (List<Inventory>) inventoryRepository.findAll();
    }

    @Override
    public Inventory getInventoryById(Long id) {
        return inventoryRepository.findById(id).orElse(null);
    }

    @Override
    public void deleteInventoryById(Long id) {
        inventoryRepository.deleteById(id);
    }

    @Override
    public List<Inventory> getInventoryByProductName(String productName) {
        return inventoryRepository.findByProductName(productName);
    }
}
