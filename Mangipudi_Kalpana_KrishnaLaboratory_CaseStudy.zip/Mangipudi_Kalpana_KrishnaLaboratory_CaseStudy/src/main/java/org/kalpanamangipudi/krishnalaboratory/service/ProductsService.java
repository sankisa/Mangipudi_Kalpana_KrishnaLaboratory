package org.kalpanamangipudi.krishnalaboratory.service;

import org.kalpanamangipudi.krishnalaboratory.entity.Products;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface ProductsService {
    public List<Products> getAllProducts();
    Products getProductById(Long id);

    void saveProduct(Products product);
    void deleteProduct(Long id);
}
