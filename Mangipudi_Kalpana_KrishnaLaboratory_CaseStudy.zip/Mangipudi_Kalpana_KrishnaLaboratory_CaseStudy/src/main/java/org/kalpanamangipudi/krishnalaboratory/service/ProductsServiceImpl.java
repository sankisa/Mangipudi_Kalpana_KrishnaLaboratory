package org.kalpanamangipudi.krishnalaboratory.service;

import org.kalpanamangipudi.krishnalaboratory.entity.Products;
import org.kalpanamangipudi.krishnalaboratory.repository.ProductsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class ProductsServiceImpl implements ProductsService{
    private final ProductsRepository productsRepository;
    private Iterable<Products> productsIterable;

    @Autowired
    public ProductsServiceImpl(ProductsRepository productsRepository) {
        this.productsRepository = productsRepository;
    }
    @Override
    public List<Products> getAllProducts() {
        return (List<Products>)productsRepository.findAll();
    }

    @Override
    public Products getProductById(Long id) {
        Optional<Products> productOptional = productsRepository.findById(id);
        return productOptional.orElse(null);

    }

    @Override
    public void saveProduct(Products product) {
        productsRepository.save(product);
    }

    @Override
    public void deleteProduct(Long id) {
        productsRepository.deleteById(id);

    }
}
