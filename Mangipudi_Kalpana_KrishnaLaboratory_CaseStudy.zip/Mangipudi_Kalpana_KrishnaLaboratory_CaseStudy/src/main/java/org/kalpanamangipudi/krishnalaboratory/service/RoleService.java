package org.kalpanamangipudi.krishnalaboratory.service;

import org.kalpanamangipudi.krishnalaboratory.entity.Role;

import java.util.List;
import java.util.Optional;

public interface RoleService {



    public void saveRole(Role role);
    public Optional<Role> findRoleByName(String name);
    public List<Role> getAllRoles();
    public List<Role> getRolesByUser(long id);

}
