package org.kalpanamangipudi.krishnalaboratory.service;

import org.kalpanamangipudi.krishnalaboratory.dto.UserDTO;
import org.kalpanamangipudi.krishnalaboratory.entity.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;

public interface UserService extends UserDetailsService {
    public User findUserByEmailForSecurity(String email);
    public UserDetails loadUserByUsername(String username);
    public void saveUser(UserDTO userDTO);
    public UserDTO findUserByEmail(String email);
    public User findUserByName(String username);
    public void processForgotPassword(String email);

    public boolean verifyPasswordResetToken(String token);

    public boolean resetPassword(String token, String newPassword);




}






