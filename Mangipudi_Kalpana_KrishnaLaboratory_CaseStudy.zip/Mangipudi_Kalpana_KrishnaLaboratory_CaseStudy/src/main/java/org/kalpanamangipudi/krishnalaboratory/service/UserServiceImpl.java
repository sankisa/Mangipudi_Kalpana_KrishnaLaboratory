package org.kalpanamangipudi.krishnalaboratory.service;

import org.kalpanamangipudi.krishnalaboratory.dto.UserDTO;
import org.kalpanamangipudi.krishnalaboratory.entity.Role;
import org.kalpanamangipudi.krishnalaboratory.entity.User;
import org.kalpanamangipudi.krishnalaboratory.repository.UserRepository;
import org.springframework.context.annotation.Lazy;
import jakarta.transaction.Transactional;


import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class UserServiceImpl implements UserService {


    private UserRepository userRepository;


    private RoleService roleService;


    private BCryptPasswordEncoder encoder;

    @Autowired
    public UserServiceImpl(UserRepository userRepository, RoleService roleService, @Lazy BCryptPasswordEncoder encoder) {
        this.userRepository = userRepository;
        this.roleService = roleService;
        this.encoder = encoder;
    }

    @Override
    public User findUserByEmailForSecurity(String email) {
        return null;
    }
@Transactional
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findUserByEmail(username);
        if (user != null) {
            return buildUserDetails(user);
        } else {
            throw new UsernameNotFoundException("User with username " + username + " not found");
        }
    }
    private UserDetails buildUserDetails(User user) {
        return new org.springframework.security.core.userdetails.User(
                user.getEmail(),
                user.getPassword(),
                user.getRoles().stream()
                        .map(role -> new SimpleGrantedAuthority(role.getName()))
                        .collect(Collectors.toList())
        );
    }





        private Collection<? extends GrantedAuthority> mapRolesToAuthorities(Collection<Role> roles) {
        return roles.stream().map(role -> new SimpleGrantedAuthority(role.getName())).collect(Collectors.toList());
    }

    @Transactional
    public void saveUser(UserDTO userDTO)
    {
        ModelMapper modelMapper = new ModelMapper();
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        User user = modelMapper.map(userDTO, User.class);

        user.setPassword(encoder.encode(user.getPassword()));
        Optional<Role> roleOptional = roleService.findRoleByName("ROLE_USER");

        userRepository.save(user);
    }

@Transactional
    public UserDTO findUserByEmail(String email) {
        Optional<User> userOptional = Optional.ofNullable(userRepository.findUserByEmail(email));

        if (userOptional.isPresent()) {

            ModelMapper modelMapper = new ModelMapper();
            modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);

            UserDTO userDTO = modelMapper.map(userOptional.get(), UserDTO.class);

            return userDTO;
        } else
            throw new RuntimeException("User does not exist");

    }


@Transactional
    @Override
    public User findUserByName(String username) {

            if (username == null || username.isEmpty()) {
                throw new IllegalArgumentException("Username cannot be null or empty");
            }

            User user = userRepository.findUserByUsername(username);

            if (user == null) {
                log.warn("User with username {} not found", username);

            }

            return user;


    }

    @Override
    public void processForgotPassword(String email) {

    }

    @Override
    public boolean verifyPasswordResetToken(String token) {
        return false;
    }

    @Override
    public boolean resetPassword(String token, String newPassword) {
        return false;
    }




}
