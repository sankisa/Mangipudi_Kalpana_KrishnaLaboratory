
    document.getElementById("book-appointment-button").addEventListener("click", function () {

        window.location.href = "/confirm-appointment";
    });
