function validationContactForm(){
const contactForm = document.getElementById('contactForm');
const submitButton = contactForm.querySelector('input[type="submit"]');


contactForm.addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent the default form submission

    const name = contactForm.querySelector('#name').value;
    const email = contactForm.querySelector('#email').value;
    const message = contactForm.querySelector('#message').value;

    if (name && email && message) {

        alert('Form submitted successfully!');
    } else {
        alert('Please fill in all the required fields.');
    }
window.location.href = "/index";
});