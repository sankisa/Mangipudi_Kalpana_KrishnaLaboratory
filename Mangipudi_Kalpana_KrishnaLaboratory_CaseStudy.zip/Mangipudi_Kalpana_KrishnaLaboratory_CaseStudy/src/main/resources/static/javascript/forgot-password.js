function validateForgotPasswordForm() {
    var emailInput = document.getElementById("email");
    var emailValue = emailInput.value.trim();

    if (emailValue === "") {
        alert("Email or username is required.");
        emailInput.focus();
        return false;
    }

    return true;
}