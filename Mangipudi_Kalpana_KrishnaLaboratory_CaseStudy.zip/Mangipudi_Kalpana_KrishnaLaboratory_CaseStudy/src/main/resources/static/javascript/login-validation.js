
document.addEventListener("DOMContentLoaded", function() {
    var loginForm = document.getElementById("loginForm");

    if (loginForm) {
        loginForm.addEventListener("submit", function(event) {
            event.preventDefault(); // Prevent the default form submission

            // Perform your login validation logic here
            var username = document.getElementById("username").value;
            var password = document.getElementById("password").value;

            //  Validate that the username and password are not empty
            if (username.trim() === "" || password.trim() === "") {
                alert("Please enter both username and password.");
                return;
            }


            loginForm.submit();
        });
    }
});