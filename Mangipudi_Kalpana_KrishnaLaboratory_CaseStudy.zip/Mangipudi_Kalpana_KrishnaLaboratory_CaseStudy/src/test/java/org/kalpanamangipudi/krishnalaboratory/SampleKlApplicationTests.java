package org.kalpanamangipudi.krishnalaboratory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleKlApplicationTests {

	@Test
	void contextLoads() {
	}

}
