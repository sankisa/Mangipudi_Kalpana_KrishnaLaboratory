package org.kalpanamangipudi.krishnalaboratory.repository;

import org.kalpanamangipudi.krishnalaboratory.entity.ContactForm;
import org.junit.jupiter.api.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.annotation.Order;


import java.util.List;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ContactFormRepositoryTest {

    @Autowired
    private ContactFormRepository contactFormRepository;

    ContactForm contactForm;


    @BeforeEach
    public void init() {
        contactForm = new ContactForm();
        contactForm.setName("Kalyani");
        contactForm.setEmail("kalpana@test.com");
        contactForm.setMessage("Dummy message");
    }

    @Test
    public void testSaveContactForm() {
        contactFormRepository.save(contactForm);
        Assertions.assertTrue(contactFormRepository.count() > 0);
    }

    @Test
    @Order(2)
    public void testContactFormDetails() {
     List<ContactForm> contactEmail =contactFormRepository.findByEmail("kalpana@test.com");
        Assertions.assertNotNull(contactForm, "Contact forms list is null");
        Assertions.assertFalse(contactEmail.isEmpty(), "Contact forms list is empty");
        for (ContactForm contactForm : contactEmail) {
            Assertions.assertEquals("kalpana@test.com", contactForm.getEmail(), "Email does not match");
        }
        System.out.println("Found contact forms for email 'kalpana@test.com': " + contactForm);

    }
}