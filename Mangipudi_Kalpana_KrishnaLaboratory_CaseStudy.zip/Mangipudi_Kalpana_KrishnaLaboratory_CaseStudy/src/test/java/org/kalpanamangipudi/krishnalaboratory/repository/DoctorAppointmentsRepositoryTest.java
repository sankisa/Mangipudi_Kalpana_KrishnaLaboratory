package org.kalpanamangipudi.krishnalaboratory.repository;

import org.kalpanamangipudi.krishnalaboratory.entity.DoctorAppointments;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.annotation.Order;


import java.util.Date;

@Transactional
@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class DoctorAppointmentsRepositoryTest {
    @Autowired
    DoctorAppointmentsRepository doctorAppointmentsRepository;
    DoctorAppointments doctorAppointments;



    @BeforeEach
    public void init() {
        doctorAppointments = new DoctorAppointments();
        doctorAppointments.setDoctorName("Sam");
        doctorAppointments.setContactNumber("123-456-5672");
        doctorAppointments.setPatientName("Lase");
    }

        @Test
        @Order(1)
        public void testSaveDoctorAppointments() {
            doctorAppointmentsRepository.save(doctorAppointments);
            Assertions.assertTrue(doctorAppointmentsRepository.count() > 0);
        }
        @Test
        @Order(2)
        public void testFindDoctorByPatientName(){
            DoctorAppointments doctor = doctorAppointmentsRepository.findDoctorByPatientName("Kailey");


             Assertions.assertNotNull(doctor, "Doctor not found for patient 'Kailey'");

            System.out.println("Found doctor for patient 'Kailey': " + doctor);
        }

        @Test
    @Order(3)
    public void testFindPatientByDoctorName(){
        DoctorAppointments patient=doctorAppointmentsRepository.findByDoctorName("Pinky");
        Assertions.assertEquals("Kailey", "Kailey");
        System.out.println("test passed");
        }
@Test
    @Order(4)
    public void testSaveDoctorAppoinments(){
        doctorAppointments.setDoctorName("Asha");
        doctorAppointments.setPatientName("Rinku");
        doctorAppointments.setAppointmentTime("12:30PM");
    Date testDate = new Date();
    doctorAppointments.setDate(testDate);
    DoctorAppointments docAppointments=doctorAppointmentsRepository.save(doctorAppointments);
    Assertions.assertNotNull(docAppointments, "Doctor Appointments not saved");
    Assertions.assertEquals(testDate, docAppointments.getDate(), "Appointment date does not match");
    System.out.println("Saved doctor with appointment date: " + docAppointments);


}

      }




