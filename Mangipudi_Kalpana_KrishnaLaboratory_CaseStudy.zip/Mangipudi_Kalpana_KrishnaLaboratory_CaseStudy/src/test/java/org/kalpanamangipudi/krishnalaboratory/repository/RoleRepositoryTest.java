package org.kalpanamangipudi.krishnalaboratory.repository;

import org.kalpanamangipudi.krishnalaboratory.entity.Role;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.*;

import org.kalpanamangipudi.krishnalaboratory.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.Rollback;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@Transactional
@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class RoleRepositoryTest {


    @Autowired
    private RoleRepository roleRepository;

    private Role role;

    @BeforeEach
    public void init() {
        role = new Role();
        role.setRoleName("ROLE_CUSTOMER");
        roleRepository.save(role);
    }

    @Test
    @Order(1)
    public void testSaveRole() {


        Optional<Role> savedRoleOptional = roleRepository.findRoleByName("ROLE_CUSTOMER");


        Assertions.assertTrue(savedRoleOptional.isPresent());
        Role savedRole = savedRoleOptional.get();
    }
@Order(2)
    @Test
    public void testFindRoleByName() {
        String expectedNameOfRole = "ROLE_CUSTOMER";
        Optional<Role> actualRoleOptional = roleRepository.findRoleByName(expectedNameOfRole);

    Assertions.assertTrue(actualRoleOptional.isPresent());
    Role actualRole = actualRoleOptional.get();
    assertEquals(expectedNameOfRole, actualRole.getRoleName());
    Assertions.assertTrue(roleRepository.count() > 0);
}


    }
