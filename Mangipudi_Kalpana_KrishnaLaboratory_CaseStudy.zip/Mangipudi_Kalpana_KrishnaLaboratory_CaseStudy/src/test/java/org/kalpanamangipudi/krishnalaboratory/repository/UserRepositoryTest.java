package org.kalpanamangipudi.krishnalaboratory.repository;

import org.kalpanamangipudi.krishnalaboratory.entity.Role;
import org.kalpanamangipudi.krishnalaboratory.entity.User;
import org.kalpanamangipudi.krishnalaboratory.service.UserService;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.transaction.annotation.Transactional;


import java.util.Arrays;

@SpringBootTest
@Transactional
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class UserRepositoryTest {

@Autowired
UserService userService;
    @Autowired
    UserRepository userRepository;
    @Autowired
    RoleRepository roleRepository;
    @Autowired
    private EntityManager entityManager;

    @Autowired
    BCryptPasswordEncoder passwordEncoder;
    User user;

    Role role;




    @BeforeEach
    public void init() {
        role = new Role();
        role.setName("ROLE_CUSTOMER");
        roleRepository.save(role);

        user = new User();

       user.setFirstName("sankisa");
       user.setLastName("kalpana");
       user.setEmail("web@test.com");
       user.setCountry("USA");
       user.setUsername("mangipudi");
       user.setAge(40);
        user.setRoles(Arrays.asList(new Role("ROLE_CUSTOMER")));
        user.setPassword(passwordEncoder.encode("kalpana98765"));
        user.setConfirmPassword("kalpana98765");
        userRepository.save(user);
        entityManager.flush();
    }

    @Test
    @Order(1)
    public void testSaveUser() {
        Assertions.assertTrue(userRepository.count() > 0);
    }

    @Test
    @Order(2)
    public void testFindUserByEmail() {
        User foundUser = userRepository.findUserByEmail("web@test.com");

        Assertions.assertEquals("web@test.com", foundUser.getEmail());
    }


    @Test
    @Order(3)
    public void testFindUserByUsername() {
        User foundUser = userRepository.findUserByUsername("ananthk09");
        Assertions.assertNotNull(foundUser);
        Assertions.assertEquals("ananthk09", foundUser.getUsername());
    }

    @Test
    @Order(4)
    public void testFindUserByNonexistentUsername() {
        User foundUser = userRepository.findUserByUsername("abcd");
        Assertions.assertNull(foundUser, "User with username 'abcd' should not exist.");
    }
    @Test
    @Order(5)
    public void testFindUserByUserId() {
        User foundUsers = userRepository.findByUserId(1L);

        Assertions.assertFalse(foundUsers == null, "No user found for user ID 1");

        // Log a warning if there are multiple users with the same ID
        if (foundUsers != null) {
            System.out.println("User found");
        }
    }

    }

