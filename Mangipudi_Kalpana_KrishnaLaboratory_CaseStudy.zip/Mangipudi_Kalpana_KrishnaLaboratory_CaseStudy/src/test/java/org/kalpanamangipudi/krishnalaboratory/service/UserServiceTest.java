package org.kalpanamangipudi.krishnalaboratory.service;

import org.kalpanamangipudi.krishnalaboratory.dto.UserDTO;
import org.kalpanamangipudi.krishnalaboratory.entity.Role;
import org.kalpanamangipudi.krishnalaboratory.repository.RoleRepository;
import org.kalpanamangipudi.krishnalaboratory.repository.UserRepository;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class UserServiceTest {
    @Autowired
    UserService userService;

    @Autowired
    RoleRepository roleRepository;

    @Autowired
    UserRepository userRepository;

    UserDTO userDTO;

    Role role;

    @BeforeAll
    public void setUp()
    {
        role = new Role();
        role.setRoleName("ROLE_PHARMA");
        roleRepository.save(role);
    }
    @BeforeEach
    public void init()
    {

        userDTO = new UserDTO();
        userDTO.setEmail("123@test.com");
        userDTO.setPassword("1234678");
        userDTO.setFirstName("Kalpana");
        userDTO.setLastName("Mangipudi");
        userDTO.setConfirmPassword("1234678");
    }
    @Test
    @Order(1)
    public void testSaveUser(){

        userService.saveUser(userDTO);
        Assertions.assertTrue(userRepository.count() > 0);
    }




}
